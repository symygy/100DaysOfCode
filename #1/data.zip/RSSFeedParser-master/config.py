LOGIN = wpisz sw�j email google
KEY = wpisz API key do konta email google
DATABASE_NAME = 'data.db'